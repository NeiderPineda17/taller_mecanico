<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Repuesto extends Model
{
    use HasFactory;

    protected $table = 'repuestos';
    protected $fillable = ['nombre', 'codigo', 'stock', 'precio'];

    public function servicios()
    {
        return $this->belongsToMany(Servicio::class, 'repuesto_servicio')
                    ->withPivot('cantidad', 'precio_unitario')
                    ->withTimestamps();
    }
}
