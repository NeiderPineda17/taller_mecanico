<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Servicio extends Model
{
    use HasFactory;

    protected $table = 'servicios';
    protected $fillable = ['vehiculo_id', 'tipo', 'descripcion', 'costo_mano_obra', 'total', 'fecha'];
    protected $casts = [
        'fecha' => 'datetime',
    ];

    public function vehiculo()
    {
        return $this->belongsTo(Vehiculo::class);
    }

    public function repuestos()
    {
        return $this->belongsToMany(Repuesto::class, 'repuesto_servicio')
                    ->withPivot('cantidad', 'precio_unitario')
                    ->withTimestamps();
    }

    public function presupuesto()
    {
        return $this->hasOne(Presupuesto::class);
    }
}
