<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use App\Models\Vehiculo;
use App\Models\Servicio;
use App\Models\Presupuesto;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'clientes' => Cliente::count(),
            'vehiculos' => Vehiculo::count(),
            'servicios_progreso' => Servicio::where('estado', 'en_progreso')->count(),
            'ingresos' => Presupuesto::sum('total') ?? 0,
        ];

        return view('dashboard', compact('stats'));
    }
}
