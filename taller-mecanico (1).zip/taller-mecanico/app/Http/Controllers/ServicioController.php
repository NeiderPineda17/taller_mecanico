<?php

namespace App\Http\Controllers;

use App\Models\Servicio;
use App\Models\Vehiculo;
use App\Models\Repuesto;
use Illuminate\Http\Request;

class ServicioController extends Controller
{
    public function index()
    {
        $servicios = Servicio::with('vehiculo.cliente')->get();
        return view('servicios.index', compact('servicios'));
    }

    public function create()
    {
        $vehiculos = Vehiculo::with('cliente')->get();
        $repuestos = Repuesto::all();
        return view('servicios.form', compact('vehiculos', 'repuestos'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'vehiculo_id' => 'required|exists:vehiculos,id',
            'tipo' => 'required|string|max:255',
            'descripcion' => 'nullable|string',
            'costo_mano_obra' => 'nullable|numeric',
            'total' => 'nullable|numeric',
            'fecha' => 'nullable|date',
        ]);

        Servicio::create($request->all());

        return redirect()->route('servicios.index')->with('success', 'Servicio creado correctamente');
    }

    public function show(Servicio $servicio)
    {
        return view('servicios.show', compact('servicio'));
    }

    public function edit(Servicio $servicio)
    {
        $vehiculos = Vehiculo::with('cliente')->get();
        $repuestos = Repuesto::all();
        return view('servicios.form', compact('servicio', 'vehiculos', 'repuestos'));
    }

    public function update(Request $request, Servicio $servicio)
    {
        $request->validate([
            'vehiculo_id' => 'required|exists:vehiculos,id',
            'tipo' => 'required|string|max:255',
            'descripcion' => 'nullable|string',
            'costo_mano_obra' => 'nullable|numeric',
            'total' => 'nullable|numeric',
            'fecha' => 'nullable|date',
        ]);

        $servicio->update($request->all());

        return redirect()->route('servicios.index')->with('success', 'Servicio actualizado correctamente');
    }

    public function destroy(Servicio $servicio)
    {
        $servicio->delete();
        return redirect()->route('servicios.index')->with('success', 'Servicio eliminado correctamente');
    }
}
