<?php

namespace App\Http\Controllers;

use App\Models\Repuesto;
use Illuminate\Http\Request;

class RepuestoController extends Controller
{
    public function index()
    {
        $repuestos = Repuesto::all();
        return view('repuestos.index', compact('repuestos'));
    }

    public function create()
    {
        return view('repuestos.form');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'codigo' => 'nullable|string|unique:repuestos',
            'stock' => 'required|integer|min:0',
            'precio' => 'required|numeric|min:0',
        ]);

        Repuesto::create($request->all());

        return redirect()->route('repuestos.index')->with('success', 'Repuesto creado correctamente');
    }

    public function show(Repuesto $repuesto)
    {
        return view('repuestos.show', compact('repuesto'));
    }

    public function edit(Repuesto $repuesto)
    {
        return view('repuestos.form', compact('repuesto'));
    }

    public function update(Request $request, Repuesto $repuesto)
    {
        $request->validate([
            'nombre' => 'required|string|max:255',
            'codigo' => 'nullable|string|unique:repuestos,codigo,' . $repuesto->id,
            'stock' => 'required|integer|min:0',
            'precio' => 'required|numeric|min:0',
        ]);

        $repuesto->update($request->all());

        return redirect()->route('repuestos.index')->with('success', 'Repuesto actualizado correctamente');
    }

    public function destroy(Repuesto $repuesto)
    {
        $repuesto->delete();
        return redirect()->route('repuestos.index')->with('success', 'Repuesto eliminado correctamente');
    }
}
