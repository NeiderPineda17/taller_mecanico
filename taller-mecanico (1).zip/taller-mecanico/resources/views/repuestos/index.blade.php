@extends('layouts.app')

@section('title', 'Repuestos')

@section('content')
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-800">Inventario de Repuestos</h1>
            <p class="text-gray-600 mt-2">Gestiona el stock de repuestos</p>
        </div>
        <a href="{{ route('repuestos.create') }}" class="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-6 rounded-lg transition flex items-center space-x-2">
            <i class="fas fa-plus"></i>
            <span>Nuevo Repuesto</span>
        </a>
    </div>

    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
        <!-- Search Bar -->
        <div class="p-6 border-b border-gray-200">
            <input type="text" placeholder="Buscar repuesto por nombre o código..." 
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600">
        </div>

        <!-- Table -->
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50 border-b-2 border-gray-200">
                    <tr>
                        <th class="px-6 py-3 text-left font-semibold text-gray-700">Nombre</th>
                        <th class="px-6 py-3 text-left font-semibold text-gray-700">Código</th>
                        <th class="px-6 py-3 text-center font-semibold text-gray-700">Stock</th>
                        <th class="px-6 py-3 text-right font-semibold text-gray-700">Precio Unitario</th>
                        <th class="px-6 py-3 text-right font-semibold text-gray-700">Valor Total</th>
                        <th class="px-6 py-3 text-center font-semibold text-gray-700">Estado</th>
                        <th class="px-6 py-3 text-center font-semibold text-gray-700">Acciones</th>
                    </tr>
                </thead>
                <tbody class="divide-y">
                    @if(isset($repuestos) && $repuestos->count() > 0)
                        @foreach($repuestos as $repuesto)
                            <tr class="hover:bg-gray-50 transition">
                                <td class="px-6 py-4">
                                    <div class="flex items-center space-x-3">
                                        <i class="fas fa-box text-purple-600 text-lg"></i>
                                        <span class="text-gray-800 font-semibold">{{ $repuesto->nombre }}</span>
                                    </div>
                                </td>
                                <td class="px-6 py-4">
                                    <span class="bg-gray-200 px-3 py-1 rounded text-sm font-mono">{{ $repuesto->codigo ?? '-' }}</span>
                                </td>
                                <td class="px-6 py-4 text-center font-semibold">
                                    <span class="text-lg">{{ $repuesto->stock }}</span>
                                </td>
                                <td class="px-6 py-4 text-right">
                                    <span class="text-gray-800 font-semibold">${{ number_format($repuesto->precio, 2) }}</span>
                                </td>
                                <td class="px-6 py-4 text-right">
                                    <span class="text-green-600 font-bold">${{ number_format($repuesto->stock * $repuesto->precio, 2) }}</span>
                                </td>
                                <td class="px-6 py-4 text-center">
                                    @if($repuesto->stock > 10)
                                        <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-semibold">En Stock</span>
                                    @elseif($repuesto->stock > 0)
                                        <span class="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-xs font-semibold">Bajo Stock</span>
                                    @else
                                        <span class="bg-red-100 text-red-800 px-3 py-1 rounded-full text-xs font-semibold">Agotado</span>
                                    @endif
                                </td>
                                <td class="px-6 py-4">
                                    <div class="flex justify-center space-x-3">
                                        <a href="{{ route('repuestos.show', $repuesto->id) }}" 
                                           class="text-blue-600 hover:text-blue-800 transition">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="{{ route('repuestos.edit', $repuesto->id) }}" 
                                           class="text-green-600 hover:text-green-800 transition">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="{{ route('repuestos.destroy', $repuesto->id) }}" method="POST" 
                                              class="inline" onsubmit="return confirm('¿Estás seguro?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="text-red-600 hover:text-red-800 transition">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    @else
                        <tr>
                            <td colspan="7" class="px-6 py-8 text-center text-gray-500">
                                <i class="fas fa-inbox text-4xl mb-3 block opacity-50"></i>
                                <p>No hay repuestos registrados. <a href="{{ route('repuestos.create') }}" class="text-purple-600 hover:underline">Registra uno ahora</a></p>
                            </td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
@endsection
