@extends('layouts.app')

@section('title', isset($repuesto) ? 'Editar Repuesto' : 'Nuevo Repuesto')

@section('content')
    <div class="mb-6">
        <a href="{{ route('repuestos.index') }}" class="text-purple-600 hover:text-purple-800 flex items-center space-x-2">
            <i class="fas fa-arrow-left"></i>
            <span>Volver a Repuestos</span>
        </a>
    </div>

    <div class="bg-white rounded-lg shadow-lg p-8 max-w-2xl">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">
            {{ isset($repuesto) ? 'Editar Repuesto' : 'Nuevo Repuesto' }}
        </h1>

        <form action="{{ isset($repuesto) ? route('repuestos.update', $repuesto->id) : route('repuestos.store') }}" 
              method="POST" class="space-y-6">
            @csrf
            @if(isset($repuesto))
                @method('PUT')
            @endif

            <!-- Nombre -->
            <div>
                <label for="nombre" class="block text-sm font-semibold text-gray-700 mb-2">Nombre *</label>
                <input type="text" id="nombre" name="nombre" 
                       value="{{ $repuesto->nombre ?? old('nombre') }}" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600 @error('nombre') border-red-500 @enderror"
                       placeholder="Ej: Filtro de aire"
                       required>
                @error('nombre')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Código -->
            <div>
                <label for="codigo" class="block text-sm font-semibold text-gray-700 mb-2">Código (SKU)</label>
                <input type="text" id="codigo" name="codigo" 
                       value="{{ $repuesto->codigo ?? old('codigo') }}"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600"
                       placeholder="Ej: SKU-12345">
                @error('codigo')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Stock -->
                <div>
                    <label for="stock" class="block text-sm font-semibold text-gray-700 mb-2">Stock *</label>
                    <input type="number" id="stock" name="stock" 
                           value="{{ $repuesto->stock ?? old('stock', 0) }}"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600 @error('stock') border-red-500 @enderror"
                           min="0"
                           required>
                    @error('stock')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Precio -->
                <div>
                    <label for="precio" class="block text-sm font-semibold text-gray-700 mb-2">Precio Unitario *</label>
                    <div class="flex items-center">
                        <span class="text-xl text-gray-600 mr-2">$</span>
                        <input type="number" id="precio" name="precio" 
                               value="{{ $repuesto->precio ?? old('precio', '0.00') }}"
                               class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-600 @error('precio') border-red-500 @enderror"
                               step="0.01" min="0"
                               required>
                    </div>
                    @error('precio')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <!-- Info Stock -->
            @if(isset($repuesto))
                <div class="bg-purple-50 border border-purple-200 rounded-lg p-4">
                    <h3 class="font-semibold text-gray-800 mb-3">Información de Inventario</h3>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <p class="text-sm text-gray-600">Stock Actual:</p>
                            <p class="text-2xl font-bold text-purple-600">{{ $repuesto->stock }}</p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Valor Total:</p>
                            <p class="text-2xl font-bold text-green-600">${{ number_format($repuesto->stock * $repuesto->precio, 2) }}</p>
                        </div>
                    </div>
                </div>
            @endif

            <!-- Botones -->
            <div class="flex gap-4 pt-6 border-t">
                <button type="submit" class="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-6 rounded-lg transition flex items-center space-x-2">
                    <i class="fas fa-save"></i>
                    <span>{{ isset($repuesto) ? 'Actualizar' : 'Guardar' }}</span>
                </button>
                <a href="{{ route('repuestos.index') }}" class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold py-2 px-6 rounded-lg transition">
                    Cancelar
                </a>
            </div>
        </form>
    </div>
@endsection
