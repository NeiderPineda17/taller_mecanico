@extends('layouts.app')

@section('title', 'Ver Repuesto')

@section('content')
    <div class="mb-6">
        <a href="{{ route('repuestos.index') }}" class="text-purple-600 hover:text-purple-800 flex items-center space-x-2">
            <i class="fas fa-arrow-left"></i>
            <span>Volver a Repuestos</span>
        </a>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Información Principal -->
        <div class="lg:col-span-2 bg-white rounded-lg shadow-lg p-6">
            <div class="flex justify-between items-start mb-6">
                <div>
                    <h1 class="text-3xl font-bold text-gray-800">{{ $repuesto->nombre }}</h1>
                    <p class="text-gray-600 mt-1">Repuesto ID: #{{ $repuesto->id }}</p>
                </div>
                <div class="flex space-x-2">
                    <a href="{{ route('repuestos.edit', $repuesto->id) }}" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition">
                        <i class="fas fa-edit"></i> Editar
                    </a>
                    <form action="{{ route('repuestos.destroy', $repuesto->id) }}" method="POST" class="inline" 
                          onsubmit="return confirm('¿Estás seguro?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition">
                            <i class="fas fa-trash"></i> Eliminar
                        </button>
                    </form>
                </div>
            </div>

            <!-- Código -->
            @if($repuesto->codigo)
                <div class="bg-gray-100 p-4 rounded-lg border-l-4 border-gray-600 mb-6">
                    <p class="text-sm text-gray-600 font-semibold">Código (SKU)</p>
                    <p class="text-2xl font-mono font-bold text-gray-800 mt-2">{{ $repuesto->codigo }}</p>
                </div>
            @endif

            <!-- Información General -->
            <div class="space-y-4">
                <div class="border-b pb-4">
                    <p class="text-sm text-gray-600 font-semibold">Nombre del Repuesto</p>
                    <p class="text-lg text-gray-800 mt-2">{{ $repuesto->nombre }}</p>
                </div>
            </div>
        </div>

        <!-- Información de Inventario -->
        <div class="space-y-6">
            <!-- Stock -->
            <div class="bg-blue-50 rounded-lg shadow p-6 border-l-4 border-blue-600">
                <p class="text-gray-600 text-sm font-semibold">Stock Disponible</p>
                <p class="text-4xl font-bold text-blue-600 mt-2">{{ $repuesto->stock }}</p>
                @if($repuesto->stock > 10)
                    <p class="text-xs text-green-600 font-semibold mt-2">
                        <i class="fas fa-check-circle"></i> Stock suficiente
                    </p>
                @elseif($repuesto->stock > 0)
                    <p class="text-xs text-yellow-600 font-semibold mt-2">
                        <i class="fas fa-exclamation-circle"></i> Stock bajo
                    </p>
                @else
                    <p class="text-xs text-red-600 font-semibold mt-2">
                        <i class="fas fa-times-circle"></i> Agotado
                    </p>
                @endif
            </div>

            <!-- Precio Unitario -->
            <div class="bg-green-50 rounded-lg shadow p-6 border-l-4 border-green-600">
                <p class="text-gray-600 text-sm font-semibold">Precio Unitario</p>
                <p class="text-3xl font-bold text-green-600 mt-2">${{ number_format($repuesto->precio, 2) }}</p>
            </div>

            <!-- Valor Total en Inventario -->
            <div class="bg-purple-50 rounded-lg shadow p-6 border-l-4 border-purple-600">
                <p class="text-gray-600 text-sm font-semibold">Valor Total Inventario</p>
                <p class="text-3xl font-bold text-purple-600 mt-2">${{ number_format($repuesto->stock * $repuesto->precio, 2) }}</p>
            </div>

            <!-- Estado -->
            <div class="bg-gray-50 rounded-lg shadow p-6 border-l-4 border-gray-600">
                <p class="text-gray-600 text-sm font-semibold">Estado</p>
                <p class="mt-3">
                    @if($repuesto->stock > 10)
                        <span class="bg-green-100 text-green-800 px-4 py-2 rounded-full font-semibold text-sm">En Stock</span>
                    @elseif($repuesto->stock > 0)
                        <span class="bg-yellow-100 text-yellow-800 px-4 py-2 rounded-full font-semibold text-sm">Bajo Stock</span>
                    @else
                        <span class="bg-red-100 text-red-800 px-4 py-2 rounded-full font-semibold text-sm">Agotado</span>
                    @endif
                </p>
            </div>
        </div>
    </div>

    <!-- Historial de Uso -->
    @if($repuesto->servicios->count() > 0)
        <div class="mt-8 bg-white rounded-lg shadow-lg p-6">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Historial de Uso</h2>
            
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 border-b-2 border-gray-200">
                        <tr>
                            <th class="px-4 py-3 text-left font-semibold text-gray-700">Servicio</th>
                            <th class="px-4 py-3 text-left font-semibold text-gray-700">Vehículo</th>
                            <th class="px-4 py-3 text-center font-semibold text-gray-700">Cantidad</th>
                            <th class="px-4 py-3 text-right font-semibold text-gray-700">P. Unitario</th>
                            <th class="px-4 py-3 text-right font-semibold text-gray-700">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @foreach($repuesto->servicios as $servicio)
                            <tr class="hover:bg-gray-50 transition">
                                <td class="px-4 py-3">
                                    <a href="{{ route('servicios.show', $servicio->id) }}" class="text-blue-600 hover:underline font-semibold">
                                        {{ $servicio->tipo }}
                                    </a>
                                </td>
                                <td class="px-4 py-3 text-gray-600">
                                    {{ $servicio->vehiculo->marca }} {{ $servicio->vehiculo->modelo }}
                                </td>
                                <td class="px-4 py-3 text-center">{{ $servicio->pivot->cantidad }}</td>
                                <td class="px-4 py-3 text-right">${{ number_format($servicio->pivot->precio_unitario, 2) }}</td>
                                <td class="px-4 py-3 text-right font-bold text-green-600">
                                    ${{ number_format($servicio->pivot->cantidad * $servicio->pivot->precio_unitario, 2) }}
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    @endif
@endsection
