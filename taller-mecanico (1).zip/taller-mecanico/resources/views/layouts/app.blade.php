<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Taller Mecánico') - Sistema de Gestión</title>
    
    <!-- Tailwind CSS -->
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        [x-cloak] { display: none !important; }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navbar -->
    <nav class="bg-white shadow-lg border-b-4 border-blue-600">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center space-x-3">
                    <i class="fas fa-tools text-2xl text-blue-600"></i>
                    <span class="text-xl font-bold text-gray-800">Taller Mecánico</span>
                </div>
                
                <div class="hidden md:flex space-x-8">
                    <a href="{{ route('dashboard') }}" class="text-gray-700 hover:text-blue-600 transition font-medium">
                        <i class="fas fa-home"></i> Inicio
                    </a>
                    <a href="{{ route('clientes.index') }}" class="text-gray-700 hover:text-blue-600 transition font-medium">
                        <i class="fas fa-users"></i> Clientes
                    </a>
                    <a href="{{ route('vehiculos.index') }}" class="text-gray-700 hover:text-blue-600 transition font-medium">
                        <i class="fas fa-car"></i> Vehículos
                    </a>
                    <a href="{{ route('servicios.index') }}" class="text-gray-700 hover:text-blue-600 transition font-medium">
                        <i class="fas fa-wrench"></i> Servicios
                    </a>
                    <a href="{{ route('repuestos.index') }}" class="text-gray-700 hover:text-blue-600 transition font-medium">
                        <i class="fas fa-boxes"></i> Repuestos
                    </a>
                </div>

                <div class="flex items-center space-x-4">
                    <button class="relative text-gray-700 hover:text-blue-600 transition">
                        <i class="fas fa-bell text-xl"></i>
                        <span class="absolute top-0 right-0 inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-red-600 rounded-full">3</span>
                    </button>
                    <div class="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold cursor-pointer hover:bg-blue-700 transition">
                        {{ substr(auth()->user()->name ?? 'Admin', 0, 1) ?? 'A' }}
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="max-w-7xl mx-auto px-4 py-8">
        @if (session('success'))
            <div class="mb-4 p-4 bg-green-100 border border-green-400 text-green-700 rounded-lg flex items-center">
                <i class="fas fa-check-circle mr-3"></i>
                {{ session('success') }}
            </div>
        @endif

        @if (session('error'))
            <div class="mb-4 p-4 bg-red-100 border border-red-400 text-red-700 rounded-lg flex items-center">
                <i class="fas fa-exclamation-circle mr-3"></i>
                {{ session('error') }}
            </div>
        @endif

        @yield('content')
    </div>

    <!-- Footer -->
    <footer class="bg-gray-800 text-gray-300 mt-12 py-8">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <p>&copy; 2024 Taller Mecánico - Sistema de Gestión. Todos los derechos reservados.</p>
        </div>
    </footer>

    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</body>
</html>
