@extends('layouts.app')

@section('title', 'Ver Cliente')

@section('content')
    <div class="mb-6">
        <a href="{{ route('clientes.index') }}" class="text-blue-600 hover:text-blue-800 flex items-center space-x-2">
            <i class="fas fa-arrow-left"></i>
            <span>Volver a Clientes</span>
        </a>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Información del Cliente -->
        <div class="lg:col-span-2 bg-white rounded-lg shadow-lg p-6">
            <div class="flex justify-between items-start mb-6">
                <div>
                    <h1 class="text-3xl font-bold text-gray-800">{{ $cliente->nombre }}</h1>
                    <p class="text-gray-600 mt-1">Información del cliente</p>
                </div>
                <div class="flex space-x-2">
                    <a href="{{ route('clientes.edit', $cliente->id) }}" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition">
                        <i class="fas fa-edit"></i> Editar
                    </a>
                    <form action="{{ route('clientes.destroy', $cliente->id) }}" method="POST" class="inline" 
                          onsubmit="return confirm('¿Estás seguro?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition">
                            <i class="fas fa-trash"></i> Eliminar
                        </button>
                    </form>
                </div>
            </div>

            <div class="space-y-4">
                <div class="border-b pb-4">
                    <p class="text-sm text-gray-600 font-semibold">Teléfono</p>
                    <p class="text-lg text-gray-800">{{ $cliente->telefono ?? 'No especificado' }}</p>
                </div>
                <div class="border-b pb-4">
                    <p class="text-sm text-gray-600 font-semibold">Email</p>
                    <p class="text-lg text-gray-800">{{ $cliente->email ?? 'No especificado' }}</p>
                </div>
                <div class="pb-4">
                    <p class="text-sm text-gray-600 font-semibold">Dirección</p>
                    <p class="text-lg text-gray-800">{{ $cliente->direccion ?? 'No especificada' }}</p>
                </div>
            </div>
        </div>

        <!-- Estadísticas -->
        <div class="space-y-6">
            <div class="bg-blue-50 rounded-lg shadow p-6 border-l-4 border-blue-600">
                <p class="text-gray-600 text-sm font-semibold">Total de Vehículos</p>
                <p class="text-4xl font-bold text-blue-600 mt-2">{{ $cliente->vehiculos->count() }}</p>
            </div>

            <div class="bg-green-50 rounded-lg shadow p-6 border-l-4 border-green-600">
                <p class="text-gray-600 text-sm font-semibold">Servicios Realizados</p>
                <p class="text-4xl font-bold text-green-600 mt-2">
                    {{ $cliente->vehiculos->flatMap(fn($v) => $v->servicios)->count() }}
                </p>
            </div>

            <div class="bg-purple-50 rounded-lg shadow p-6 border-l-4 border-purple-600">
                <p class="text-gray-600 text-sm font-semibold">Total Gastado</p>
                <p class="text-3xl font-bold text-purple-600 mt-2">
                    ${{ number_format($cliente->vehiculos->flatMap(fn($v) => $v->servicios)->sum('total'), 2) }}
                </p>
            </div>
        </div>
    </div>

    <!-- Vehículos del Cliente -->
    <div class="mt-8 bg-white rounded-lg shadow-lg p-6">
        <h2 class="text-2xl font-bold text-gray-800 mb-6">Vehículos del Cliente</h2>
        
        @if($cliente->vehiculos->count() > 0)
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                @foreach($cliente->vehiculos as $vehiculo)
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-lg transition">
                        <div class="bg-gray-200 h-32 rounded flex items-center justify-center mb-4">
                            @if($vehiculo->foto)
                                <img src="{{ $vehiculo->foto }}" alt="{{ $vehiculo->marca }}" class="w-full h-full object-cover rounded">
                            @else
                                <i class="fas fa-car text-4xl text-gray-400"></i>
                            @endif
                        </div>
                        <h3 class="font-bold text-gray-800">{{ $vehiculo->marca }} {{ $vehiculo->modelo }}</h3>
                        <p class="text-sm text-gray-600">Placa: <span class="bg-yellow-300 px-2 py-1 rounded">{{ $vehiculo->placa }}</span></p>
                        <p class="text-sm text-gray-600">Año: {{ $vehiculo->anio ?? 'N/A' }}</p>
                        <a href="{{ route('vehiculos.show', $vehiculo->id) }}" class="text-blue-600 hover:underline text-sm mt-3 inline-block">
                            Ver detalles →
                        </a>
                    </div>
                @endforeach
            </div>
        @else
            <div class="text-center py-12">
                <i class="fas fa-car text-4xl text-gray-300 mb-4 block"></i>
                <p class="text-gray-500">Este cliente no tiene vehículos registrados</p>
            </div>
        @endif
    </div>
@endsection
