@extends('layouts.app')

@section('title', isset($cliente) ? 'Editar Cliente' : 'Nuevo Cliente')

@section('content')
    <div class="mb-6">
        <a href="{{ route('clientes.index') }}" class="text-blue-600 hover:text-blue-800 flex items-center space-x-2">
            <i class="fas fa-arrow-left"></i>
            <span>Volver a Clientes</span>
        </a>
    </div>

    <div class="bg-white rounded-lg shadow-lg p-8 max-w-2xl">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">
            {{ isset($cliente) ? 'Editar Cliente' : 'Nuevo Cliente' }}
        </h1>

        <form action="{{ isset($cliente) ? route('clientes.update', $cliente->id) : route('clientes.store') }}" 
              method="POST" class="space-y-6">
            @csrf
            @if(isset($cliente))
                @method('PUT')
            @endif

            <!-- Nombre -->
            <div>
                <label for="nombre" class="block text-sm font-semibold text-gray-700 mb-2">Nombre *</label>
                <input type="text" id="nombre" name="nombre" 
                       value="{{ $cliente->nombre ?? old('nombre') }}" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 @error('nombre') border-red-500 @enderror"
                       required>
                @error('nombre')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Teléfono -->
            <div>
                <label for="telefono" class="block text-sm font-semibold text-gray-700 mb-2">Teléfono</label>
                <input type="tel" id="telefono" name="telefono" 
                       value="{{ $cliente->telefono ?? old('telefono') }}"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600">
                @error('telefono')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Email -->
            <div>
                <label for="email" class="block text-sm font-semibold text-gray-700 mb-2">Email</label>
                <input type="email" id="email" name="email" 
                       value="{{ $cliente->email ?? old('email') }}"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600">
                @error('email')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Dirección -->
            <div>
                <label for="direccion" class="block text-sm font-semibold text-gray-700 mb-2">Dirección</label>
                <textarea id="direccion" name="direccion" rows="3"
                          class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600">{{ $cliente->direccion ?? old('direccion') }}</textarea>
                @error('direccion')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Botones -->
            <div class="flex gap-4 pt-6 border-t">
                <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition flex items-center space-x-2">
                    <i class="fas fa-save"></i>
                    <span>{{ isset($cliente) ? 'Actualizar' : 'Guardar' }}</span>
                </button>
                <a href="{{ route('clientes.index') }}" class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold py-2 px-6 rounded-lg transition">
                    Cancelar
                </a>
            </div>
        </form>
    </div>
@endsection
