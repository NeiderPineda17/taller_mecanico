@extends('layouts.app')

@section('title', 'Clientes')

@section('content')
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-800">Clientes</h1>
            <p class="text-gray-600 mt-2">Gestiona todos tus clientes</p>
        </div>
        <a href="{{ route('clientes.create') }}" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-6 rounded-lg transition flex items-center space-x-2">
            <i class="fas fa-plus"></i>
            <span>Nuevo Cliente</span>
        </a>
    </div>

    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
        <!-- Search Bar -->
        <div class="p-6 border-b border-gray-200">
            <input type="text" placeholder="Buscar cliente por nombre, teléfono o email..." 
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600">
        </div>

        <!-- Table -->
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50 border-b-2 border-gray-200">
                    <tr>
                        <th class="px-6 py-3 text-left font-semibold text-gray-700">Nombre</th>
                        <th class="px-6 py-3 text-left font-semibold text-gray-700">Teléfono</th>
                        <th class="px-6 py-3 text-left font-semibold text-gray-700">Email</th>
                        <th class="px-6 py-3 text-left font-semibold text-gray-700">Dirección</th>
                        <th class="px-6 py-3 text-left font-semibold text-gray-700">Vehículos</th>
                        <th class="px-6 py-3 text-center font-semibold text-gray-700">Acciones</th>
                    </tr>
                </thead>
                <tbody class="divide-y">
                    @if(isset($clientes) && $clientes->count() > 0)
                        @foreach($clientes as $cliente)
                            <tr class="hover:bg-gray-50 transition">
                                <td class="px-6 py-4">
                                    <div class="flex items-center space-x-3">
                                        <div class="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                                            {{ substr($cliente->nombre, 0, 1) }}
                                        </div>
                                        <span class="text-gray-800 font-semibold">{{ $cliente->nombre }}</span>
                                    </div>
                                </td>
                                <td class="px-6 py-4 text-gray-600">{{ $cliente->telefono ?? '-' }}</td>
                                <td class="px-6 py-4 text-gray-600">{{ $cliente->email ?? '-' }}</td>
                                <td class="px-6 py-4 text-gray-600">{{ $cliente->direccion ?? '-' }}</td>
                                <td class="px-6 py-4 text-center">
                                    <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-semibold">0</span>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="flex justify-center space-x-3">
                                        <a href="{{ route('clientes.show', $cliente->id) }}" 
                                           class="text-blue-600 hover:text-blue-800 transition" title="Ver">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="{{ route('clientes.edit', $cliente->id) }}" 
                                           class="text-green-600 hover:text-green-800 transition" title="Editar">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="{{ route('clientes.destroy', $cliente->id) }}" method="POST" 
                                              class="inline" onsubmit="return confirm('¿Estás seguro?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="text-red-600 hover:text-red-800 transition" title="Eliminar">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    @else
                        <tr>
                            <td colspan="6" class="px-6 py-8 text-center text-gray-500">
                                <i class="fas fa-inbox text-4xl mb-3 block opacity-50"></i>
                                <p>No hay clientes registrados. <a href="{{ route('clientes.create') }}" class="text-blue-600 hover:underline">Crear uno ahora</a></p>
                            </td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
@endsection
