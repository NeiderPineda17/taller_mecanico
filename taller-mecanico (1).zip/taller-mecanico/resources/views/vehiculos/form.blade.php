@extends('layouts.app')

@section('title', isset($vehiculo) ? 'Editar Vehículo' : 'Nuevo Vehículo')

@section('content')
    <div class="mb-6">
        <a href="{{ route('vehiculos.index') }}" class="text-green-600 hover:text-green-800 flex items-center space-x-2">
            <i class="fas fa-arrow-left"></i>
            <span>Volver a Vehículos</span>
        </a>
    </div>

    <div class="bg-white rounded-lg shadow-lg p-8 max-w-2xl">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">
            {{ isset($vehiculo) ? 'Editar Vehículo' : 'Nuevo Vehículo' }}
        </h1>

        <form action="{{ isset($vehiculo) ? route('vehiculos.update', $vehiculo->id) : route('vehiculos.store') }}" 
              method="POST" enctype="multipart/form-data" class="space-y-6">
            @csrf
            @if(isset($vehiculo))
                @method('PUT')
            @endif

            <!-- Cliente -->
            <div>
                <label for="cliente_id" class="block text-sm font-semibold text-gray-700 mb-2">Cliente *</label>
                <select id="cliente_id" name="cliente_id" 
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600 @error('cliente_id') border-red-500 @enderror"
                        required>
                    <option value="">Selecciona un cliente</option>
                    @if(isset($clientes))
                        @foreach($clientes as $cliente)
                            <option value="{{ $cliente->id }}" 
                                {{ (isset($vehiculo) && $vehiculo->cliente_id == $cliente->id) ? 'selected' : '' }}>
                                {{ $cliente->nombre }}
                            </option>
                        @endforeach
                    @endif
                </select>
                @error('cliente_id')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Marca -->
            <div>
                <label for="marca" class="block text-sm font-semibold text-gray-700 mb-2">Marca *</label>
                <input type="text" id="marca" name="marca" 
                       value="{{ $vehiculo->marca ?? old('marca') }}" 
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600 @error('marca') border-red-500 @enderror"
                       placeholder="Ej: Toyota, Honda, BMW"
                       required>
                @error('marca')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Modelo -->
            <div>
                <label for="modelo" class="block text-sm font-semibold text-gray-700 mb-2">Modelo *</label>
                <input type="text" id="modelo" name="modelo" 
                       value="{{ $vehiculo->modelo ?? old('modelo') }}"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600 @error('modelo') border-red-500 @enderror"
                       placeholder="Ej: Corolla, Civic"
                       required>
                @error('modelo')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Placa -->
            <div>
                <label for="placa" class="block text-sm font-semibold text-gray-700 mb-2">Placa *</label>
                <input type="text" id="placa" name="placa" 
                       value="{{ $vehiculo->placa ?? old('placa') }}"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600 @error('placa') border-red-500 @enderror uppercase"
                       placeholder="ABC-1234"
                       required>
                @error('placa')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Año -->
            <div>
                <label for="anio" class="block text-sm font-semibold text-gray-700 mb-2">Año</label>
                <input type="number" id="anio" name="anio" 
                       value="{{ $vehiculo->anio ?? old('anio') }}"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600"
                       min="1900" max="{{ date('Y') + 1 }}">
                @error('anio')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Foto -->
            <div>
                <label for="foto" class="block text-sm font-semibold text-gray-700 mb-2">Foto del Vehículo</label>
                <input type="file" id="foto" name="foto" accept="image/*"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600">
                @if(isset($vehiculo) && $vehiculo->foto)
                    <p class="text-sm text-gray-600 mt-2">Foto actual: <img src="{{ $vehiculo->foto }}" alt="Vehículo" class="inline h-12 rounded"></p>
                @endif
                @error('foto')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <!-- Botones -->
            <div class="flex gap-4 pt-6 border-t">
                <button type="submit" class="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-6 rounded-lg transition flex items-center space-x-2">
                    <i class="fas fa-save"></i>
                    <span>{{ isset($vehiculo) ? 'Actualizar' : 'Guardar' }}</span>
                </button>
                <a href="{{ route('vehiculos.index') }}" class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold py-2 px-6 rounded-lg transition">
                    Cancelar
                </a>
            </div>
        </form>
    </div>
@endsection
