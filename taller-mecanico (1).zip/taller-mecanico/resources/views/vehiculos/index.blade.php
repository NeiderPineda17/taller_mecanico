@extends('layouts.app')

@section('title', 'Vehículos')

@section('content')
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-800">Vehículos</h1>
            <p class="text-gray-600 mt-2">Administra todos los vehículos del taller</p>
        </div>
        <a href="{{ route('vehiculos.create') }}" class="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-6 rounded-lg transition flex items-center space-x-2">
            <i class="fas fa-plus"></i>
            <span>Nuevo Vehículo</span>
        </a>
    </div>

    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
        <!-- Search Bar -->
        <div class="p-6 border-b border-gray-200">
            <input type="text" placeholder="Buscar vehículo por placa, marca o modelo..." 
                   class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-600">
        </div>

        <!-- Grid View -->
        <div class="p-6">
            @if(isset($vehiculos) && $vehiculos->count() > 0)
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    @foreach($vehiculos as $vehiculo)
                        <div class="border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition">
                            <!-- Imagen -->
                            <div class="bg-gray-200 h-40 flex items-center justify-center">
                                @if($vehiculo->foto)
                                    <img src="{{ $vehiculo->foto }}" alt="{{ $vehiculo->marca }}" class="w-full h-full object-cover">
                                @else
                                    <i class="fas fa-car text-5xl text-gray-400"></i>
                                @endif
                            </div>

                            <!-- Contenido -->
                            <div class="p-4">
                                <h3 class="text-lg font-bold text-gray-800">{{ $vehiculo->marca }} {{ $vehiculo->modelo }}</h3>
                                <p class="text-gray-600 text-sm">{{ $vehiculo->anio ?? 'Año no especificado' }}</p>
                                
                                <div class="mt-4 p-3 bg-blue-50 rounded">
                                    <p class="text-sm text-gray-700">
                                        <span class="font-semibold">Placa:</span> 
                                        <span class="bg-yellow-300 px-2 py-1 rounded font-mono">{{ $vehiculo->placa }}</span>
                                    </p>
                                </div>

                                <div class="mt-4 p-3 bg-gray-50 rounded">
                                    <p class="text-sm text-gray-700">
                                        <span class="font-semibold">Cliente:</span> {{ $vehiculo->cliente->nombre ?? 'N/A' }}
                                    </p>
                                </div>

                                <!-- Acciones -->
                                <div class="mt-4 flex gap-2">
                                    <a href="{{ route('vehiculos.show', $vehiculo->id) }}" 
                                       class="flex-1 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold py-2 px-3 rounded text-center transition">
                                        <i class="fas fa-eye"></i> Ver
                                    </a>
                                    <a href="{{ route('vehiculos.edit', $vehiculo->id) }}" 
                                       class="flex-1 bg-green-600 hover:bg-green-700 text-white text-sm font-semibold py-2 px-3 rounded text-center transition">
                                        <i class="fas fa-edit"></i> Editar
                                    </a>
                                    <form action="{{ route('vehiculos.destroy', $vehiculo->id) }}" method="POST" class="flex-1"
                                          onsubmit="return confirm('¿Estás seguro?');">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="w-full bg-red-600 hover:bg-red-700 text-white text-sm font-semibold py-2 px-3 rounded transition">
                                            <i class="fas fa-trash"></i> Eliminar
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            @else
                <div class="text-center py-12">
                    <i class="fas fa-car text-6xl text-gray-300 mb-4 block"></i>
                    <p class="text-gray-500 mb-4">No hay vehículos registrados</p>
                    <a href="{{ route('vehiculos.create') }}" class="text-green-600 hover:underline">
                        Registra tu primer vehículo
                    </a>
                </div>
            @endif
        </div>
    </div>
@endsection
