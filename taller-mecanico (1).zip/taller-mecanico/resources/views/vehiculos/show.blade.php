@extends('layouts.app')

@section('title', 'Ver Vehículo')

@section('content')
    <div class="mb-6">
        <a href="{{ route('vehiculos.index') }}" class="text-green-600 hover:text-green-800 flex items-center space-x-2">
            <i class="fas fa-arrow-left"></i>
            <span>Volver a Vehículos</span>
        </a>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Información Principal -->
        <div class="lg:col-span-2 bg-white rounded-lg shadow-lg overflow-hidden">
            <div class="h-96 bg-gray-200 flex items-center justify-center">
                @if($vehiculo->foto)
                    <img src="{{ $vehiculo->foto }}" alt="{{ $vehiculo->marca }}" class="w-full h-full object-cover">
                @else
                    <i class="fas fa-car text-8xl text-gray-400"></i>
                @endif
            </div>

            <div class="p-6">
                <div class="flex justify-between items-start mb-6">
                    <div>
                        <h1 class="text-3xl font-bold text-gray-800">{{ $vehiculo->marca }} {{ $vehiculo->modelo }}</h1>
                        <p class="text-gray-600 mt-1">Año: {{ $vehiculo->anio ?? 'No especificado' }}</p>
                    </div>
                    <div class="flex space-x-2">
                        <a href="{{ route('vehiculos.edit', $vehiculo->id) }}" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition">
                            <i class="fas fa-edit"></i> Editar
                        </a>
                        <form action="{{ route('vehiculos.destroy', $vehiculo->id) }}" method="POST" class="inline" 
                              onsubmit="return confirm('¿Estás seguro?');">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition">
                                <i class="fas fa-trash"></i> Eliminar
                            </button>
                        </form>
                    </div>
                </div>

                <div class="bg-yellow-50 p-4 rounded-lg border-l-4 border-yellow-600 mb-6">
                    <p class="text-sm text-gray-600 font-semibold">Placa</p>
                    <p class="text-2xl font-mono font-bold text-yellow-600">{{ $vehiculo->placa }}</p>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div class="border-b pb-4">
                        <p class="text-sm text-gray-600 font-semibold">Marca</p>
                        <p class="text-lg text-gray-800">{{ $vehiculo->marca }}</p>
                    </div>
                    <div class="border-b pb-4">
                        <p class="text-sm text-gray-600 font-semibold">Modelo</p>
                        <p class="text-lg text-gray-800">{{ $vehiculo->modelo }}</p>
                    </div>
                    <div class="pb-4">
                        <p class="text-sm text-gray-600 font-semibold">Año</p>
                        <p class="text-lg text-gray-800">{{ $vehiculo->anio ?? 'N/A' }}</p>
                    </div>
                    <div class="pb-4">
                        <p class="text-sm text-gray-600 font-semibold">Cliente</p>
                        <p class="text-lg text-gray-800">
                            <a href="{{ route('clientes.show', $vehiculo->cliente->id) }}" class="text-blue-600 hover:underline">
                                {{ $vehiculo->cliente->nombre }}
                            </a>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Estadísticas -->
        <div class="space-y-6">
            <div class="bg-blue-50 rounded-lg shadow p-6 border-l-4 border-blue-600">
                <p class="text-gray-600 text-sm font-semibold">Total Servicios</p>
                <p class="text-4xl font-bold text-blue-600 mt-2">{{ $vehiculo->servicios->count() }}</p>
            </div>

            <div class="bg-green-50 rounded-lg shadow p-6 border-l-4 border-green-600">
                <p class="text-gray-600 text-sm font-semibold">Total Invertido</p>
                <p class="text-3xl font-bold text-green-600 mt-2">
                    ${{ number_format($vehiculo->servicios->sum('total'), 2) }}
                </p>
            </div>

            <div class="bg-gray-50 rounded-lg shadow p-6 border-l-4 border-gray-600">
                <p class="text-gray-600 text-sm font-semibold">Último Servicio</p>
                <p class="text-lg text-gray-800 mt-2">
                    {{ $vehiculo->servicios->latest('fecha')->first()?->fecha?->format('d/m/Y') ?? 'Sin servicios' }}
                </p>
            </div>
        </div>
    </div>

    <!-- Servicios -->
    <div class="mt-8 bg-white rounded-lg shadow-lg p-6">
        <h2 class="text-2xl font-bold text-gray-800 mb-6">Historial de Servicios</h2>
        
        @if($vehiculo->servicios->count() > 0)
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 border-b-2 border-gray-200">
                        <tr>
                            <th class="px-4 py-3 text-left font-semibold text-gray-700">Tipo</th>
                            <th class="px-4 py-3 text-left font-semibold text-gray-700">Descripción</th>
                            <th class="px-4 py-3 text-left font-semibold text-gray-700">Fecha</th>
                            <th class="px-4 py-3 text-right font-semibold text-gray-700">Total</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @foreach($vehiculo->servicios->sortByDesc('fecha') as $servicio)
                            <tr class="hover:bg-gray-50 transition">
                                <td class="px-4 py-3"><a href="{{ route('servicios.show', $servicio->id) }}" class="text-blue-600 hover:underline">{{ $servicio->tipo }}</a></td>
                                <td class="px-4 py-3 text-gray-600">{{ Str::limit($servicio->descripcion, 50) }}</td>
                                <td class="px-4 py-3">{{ $servicio->fecha?->format('d/m/Y') ?? 'N/A' }}</td>
                                <td class="px-4 py-3 text-right font-bold text-green-600">${{ number_format($servicio->total, 2) }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <div class="text-center py-12">
                <i class="fas fa-inbox text-4xl text-gray-300 mb-4 block"></i>
                <p class="text-gray-500">No hay servicios registrados para este vehículo</p>
            </div>
        @endif
    </div>
@endsection
