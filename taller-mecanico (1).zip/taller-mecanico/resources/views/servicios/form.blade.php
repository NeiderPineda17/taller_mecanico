@extends('layouts.app')

@section('title', isset($servicio) ? 'Editar Servicio' : 'Nuevo Servicio')

@section('content')
    <div class="mb-6">
        <a href="{{ route('servicios.index') }}" class="text-yellow-600 hover:text-yellow-800 flex items-center space-x-2">
            <i class="fas fa-arrow-left"></i>
            <span>Volver a Servicios</span>
        </a>
    </div>

    <div class="bg-white rounded-lg shadow-lg p-8 max-w-4xl">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">
            {{ isset($servicio) ? 'Editar Servicio' : 'Nuevo Servicio' }}
        </h1>

        <form action="{{ isset($servicio) ? route('servicios.update', $servicio->id) : route('servicios.store') }}" 
              method="POST" class="space-y-6">
            @csrf
            @if(isset($servicio))
                @method('PUT')
            @endif

            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Vehículo -->
                <div>
                    <label for="vehiculo_id" class="block text-sm font-semibold text-gray-700 mb-2">Vehículo *</label>
                    <select id="vehiculo_id" name="vehiculo_id" 
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-600 @error('vehiculo_id') border-red-500 @enderror"
                            required>
                        <option value="">Selecciona un vehículo</option>
                        @if(isset($vehiculos))
                            @foreach($vehiculos as $vehiculo)
                                <option value="{{ $vehiculo->id }}" 
                                    {{ (isset($servicio) && $servicio->vehiculo_id == $vehiculo->id) ? 'selected' : '' }}>
                                    {{ $vehiculo->marca }} {{ $vehiculo->modelo }} ({{ $vehiculo->placa }})
                                </option>
                            @endforeach
                        @endif
                    </select>
                    @error('vehiculo_id')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Tipo de Servicio -->
                <div>
                    <label for="tipo" class="block text-sm font-semibold text-gray-700 mb-2">Tipo de Servicio *</label>
                    <input type="text" id="tipo" name="tipo" 
                           value="{{ $servicio->tipo ?? old('tipo') }}" 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-600 @error('tipo') border-red-500 @enderror"
                           placeholder="Ej: Cambio de aceite"
                           required>
                    @error('tipo')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <!-- Descripción -->
            <div>
                <label for="descripcion" class="block text-sm font-semibold text-gray-700 mb-2">Descripción</label>
                <textarea id="descripcion" name="descripcion" rows="4"
                          class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-600"
                          placeholder="Detalles adicionales del servicio">{{ $servicio->descripcion ?? old('descripcion') }}</textarea>
                @error('descripcion')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <!-- Fecha -->
                <div>
                    <label for="fecha" class="block text-sm font-semibold text-gray-700 mb-2">Fecha del Servicio</label>
                    <input type="date" id="fecha" name="fecha" 
                           value="{{ $servicio->fecha?->format('Y-m-d') ?? old('fecha') }}"
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-600">
                    @error('fecha')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Costo Mano de Obra -->
                <div>
                    <label for="costo_mano_obra" class="block text-sm font-semibold text-gray-700 mb-2">Costo Mano de Obra</label>
                    <div class="flex items-center">
                        <span class="text-xl text-gray-600 mr-2">$</span>
                        <input type="number" id="costo_mano_obra" name="costo_mano_obra" 
                               value="{{ $servicio->costo_mano_obra ?? old('costo_mano_obra', '0.00') }}"
                               class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-600"
                               step="0.01" min="0">
                    </div>
                    @error('costo_mano_obra')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Total -->
                <div>
                    <label for="total" class="block text-sm font-semibold text-gray-700 mb-2">Total</label>
                    <div class="flex items-center">
                        <span class="text-xl text-gray-600 mr-2">$</span>
                        <input type="number" id="total" name="total" 
                               value="{{ $servicio->total ?? old('total', '0.00') }}"
                               class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-600"
                               step="0.01" min="0">
                    </div>
                    @error('total')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <!-- Repuestos -->
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">Repuestos Utilizados</label>
                <div id="repuestos-container" class="space-y-2">
                    <div class="flex gap-2">
                        <select class="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-600">
                            <option value="">Selecciona repuesto</option>
                            @if(isset($repuestos))
                                @foreach($repuestos as $repuesto)
                                    <option value="{{ $repuesto->id }}">{{ $repuesto->nombre }} - ${{ number_format($repuesto->precio, 2) }}</option>
                                @endforeach
                            @endif
                        </select>
                        <input type="number" placeholder="Cantidad" class="w-24 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-600" value="1">
                        <button type="button" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition">Añadir</button>
                    </div>
                </div>
            </div>

            <!-- Botones -->
            <div class="flex gap-4 pt-6 border-t">
                <button type="submit" class="bg-yellow-600 hover:bg-yellow-700 text-white font-semibold py-2 px-6 rounded-lg transition flex items-center space-x-2">
                    <i class="fas fa-save"></i>
                    <span>{{ isset($servicio) ? 'Actualizar' : 'Guardar' }}</span>
                </button>
                <a href="{{ route('servicios.index') }}" class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold py-2 px-6 rounded-lg transition">
                    Cancelar
                </a>
            </div>
        </form>
    </div>
@endsection
