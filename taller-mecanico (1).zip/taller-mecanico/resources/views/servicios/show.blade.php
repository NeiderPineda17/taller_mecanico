@extends('layouts.app')

@section('title', 'Ver Servicio')

@section('content')
    <div class="mb-6">
        <a href="{{ route('servicios.index') }}" class="text-yellow-600 hover:text-yellow-800 flex items-center space-x-2">
            <i class="fas fa-arrow-left"></i>
            <span>Volver a Servicios</span>
        </a>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Información Principal -->
        <div class="lg:col-span-2 bg-white rounded-lg shadow-lg p-6">
            <div class="flex justify-between items-start mb-6">
                <div>
                    <h1 class="text-3xl font-bold text-gray-800">{{ $servicio->tipo }}</h1>
                    <p class="text-gray-600 mt-1">Servicio ID: #{{ $servicio->id }}</p>
                </div>
                <div class="flex space-x-2">
                    <a href="{{ route('servicios.edit', $servicio->id) }}" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition">
                        <i class="fas fa-edit"></i> Editar
                    </a>
                    <form action="{{ route('servicios.destroy', $servicio->id) }}" method="POST" class="inline" 
                          onsubmit="return confirm('¿Estás seguro?');">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg transition">
                            <i class="fas fa-trash"></i> Eliminar
                        </button>
                    </form>
                </div>
            </div>

            <!-- Vehículo y Cliente -->
            <div class="grid grid-cols-2 gap-4 mb-6">
                <div class="bg-blue-50 p-4 rounded-lg border-l-4 border-blue-600">
                    <p class="text-sm text-gray-600 font-semibold">Vehículo</p>
                    <p class="text-lg font-bold text-gray-800 mt-2">
                        <a href="{{ route('vehiculos.show', $servicio->vehiculo->id) }}" class="text-blue-600 hover:underline">
                            {{ $servicio->vehiculo->marca }} {{ $servicio->vehiculo->modelo }}
                        </a>
                    </p>
                    <p class="text-sm text-gray-600 mt-1">Placa: <span class="font-mono font-bold">{{ $servicio->vehiculo->placa }}</span></p>
                </div>
                <div class="bg-purple-50 p-4 rounded-lg border-l-4 border-purple-600">
                    <p class="text-sm text-gray-600 font-semibold">Cliente</p>
                    <p class="text-lg font-bold text-gray-800 mt-2">
                        <a href="{{ route('clientes.show', $servicio->vehiculo->cliente->id) }}" class="text-purple-600 hover:underline">
                            {{ $servicio->vehiculo->cliente->nombre }}
                        </a>
                    </p>
                </div>
            </div>

            <!-- Detalles -->
            <div class="space-y-4 mb-6">
                <div class="border-b pb-4">
                    <p class="text-sm text-gray-600 font-semibold">Descripción</p>
                    <p class="text-gray-800 mt-2">{{ $servicio->descripcion ?? 'Sin descripción' }}</p>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <p class="text-sm text-gray-600 font-semibold">Fecha del Servicio</p>
                        <p class="text-lg text-gray-800">{{ $servicio->fecha?->format('d/m/Y') ?? 'No especificada' }}</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Costos y Totales -->
        <div class="space-y-6">
            <div class="bg-blue-50 rounded-lg shadow p-6 border-l-4 border-blue-600">
                <p class="text-gray-600 text-sm font-semibold">Costo Mano de Obra</p>
                <p class="text-3xl font-bold text-blue-600 mt-2">${{ number_format($servicio->costo_mano_obra, 2) }}</p>
            </div>

            <div class="bg-green-50 rounded-lg shadow p-6 border-l-4 border-green-600">
                <p class="text-gray-600 text-sm font-semibold">Repuestos</p>
                <p class="text-3xl font-bold text-green-600 mt-2">${{ number_format($servicio->repuestos->sum(fn($r) => $r->pivot->cantidad * $r->pivot->precio_unitario), 2) }}</p>
            </div>

            <div class="bg-red-50 rounded-lg shadow p-6 border-l-4 border-red-600">
                <p class="text-gray-600 text-sm font-semibold">Total Servicio</p>
                <p class="text-3xl font-bold text-red-600 mt-2">${{ number_format($servicio->total, 2) }}</p>
            </div>

            <div class="bg-yellow-50 rounded-lg shadow p-6 border-l-4 border-yellow-600">
                <p class="text-gray-600 text-sm font-semibold">Estado</p>
                <p class="mt-2">
                    <span class="bg-yellow-200 text-yellow-800 px-4 py-2 rounded-full font-semibold">En progreso</span>
                </p>
            </div>
        </div>
    </div>

    <!-- Repuestos Utilizados -->
    @if($servicio->repuestos->count() > 0)
        <div class="mt-8 bg-white rounded-lg shadow-lg p-6">
            <h2 class="text-2xl font-bold text-gray-800 mb-6">Repuestos Utilizados</h2>
            
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-gray-50 border-b-2 border-gray-200">
                        <tr>
                            <th class="px-4 py-3 text-left font-semibold text-gray-700">Repuesto</th>
                            <th class="px-4 py-3 text-left font-semibold text-gray-700">Código</th>
                            <th class="px-4 py-3 text-center font-semibold text-gray-700">Cantidad</th>
                            <th class="px-4 py-3 text-right font-semibold text-gray-700">P. Unitario</th>
                            <th class="px-4 py-3 text-right font-semibold text-gray-700">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @foreach($servicio->repuestos as $repuesto)
                            <tr class="hover:bg-gray-50 transition">
                                <td class="px-4 py-3 font-semibold">{{ $repuesto->nombre }}</td>
                                <td class="px-4 py-3 text-gray-600">{{ $repuesto->codigo ?? 'N/A' }}</td>
                                <td class="px-4 py-3 text-center">{{ $repuesto->pivot->cantidad }}</td>
                                <td class="px-4 py-3 text-right">${{ number_format($repuesto->pivot->precio_unitario, 2) }}</td>
                                <td class="px-4 py-3 text-right font-bold text-green-600">
                                    ${{ number_format($repuesto->pivot->cantidad * $repuesto->pivot->precio_unitario, 2) }}
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    @endif
@endsection
