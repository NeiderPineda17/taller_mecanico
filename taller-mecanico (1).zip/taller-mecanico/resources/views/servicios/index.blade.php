@extends('layouts.app')

@section('title', 'Servicios')

@section('content')
    <div class="flex justify-between items-center mb-6">
        <div>
            <h1 class="text-3xl font-bold text-gray-800">Servicios</h1>
            <p class="text-gray-600 mt-2">Administra los servicios de los vehículos</p>
        </div>
        <a href="{{ route('servicios.create') }}" class="bg-yellow-600 hover:bg-yellow-700 text-white font-semibold py-2 px-6 rounded-lg transition flex items-center space-x-2">
            <i class="fas fa-plus"></i>
            <span>Nuevo Servicio</span>
        </a>
    </div>

    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
        <!-- Filters -->
        <div class="p-6 border-b border-gray-200 bg-gray-50">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <input type="text" placeholder="Buscar por vehículo..." 
                       class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-600">
                <select class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-600">
                    <option value="">Todos los estados</option>
                    <option value="pendiente">Pendiente</option>
                    <option value="en_progreso">En progreso</option>
                    <option value="completado">Completado</option>
                </select>
                <input type="date" class="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-yellow-600">
            </div>
        </div>

        <!-- Table -->
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50 border-b-2 border-gray-200">
                    <tr>
                        <th class="px-6 py-3 text-left font-semibold text-gray-700">Tipo de Servicio</th>
                        <th class="px-6 py-3 text-left font-semibold text-gray-700">Vehículo</th>
                        <th class="px-6 py-3 text-left font-semibold text-gray-700">Cliente</th>
                        <th class="px-6 py-3 text-left font-semibold text-gray-700">Fecha</th>
                        <th class="px-6 py-3 text-left font-semibold text-gray-700">Total</th>
                        <th class="px-6 py-3 text-center font-semibold text-gray-700">Estado</th>
                        <th class="px-6 py-3 text-center font-semibold text-gray-700">Acciones</th>
                    </tr>
                </thead>
                <tbody class="divide-y">
                    @if(isset($servicios) && $servicios->count() > 0)
                        @foreach($servicios as $servicio)
                            <tr class="hover:bg-gray-50 transition">
                                <td class="px-6 py-4">
                                    <div class="flex items-center space-x-2">
                                        <i class="fas fa-wrench text-yellow-600"></i>
                                        <span class="text-gray-800 font-semibold">{{ $servicio->tipo }}</span>
                                    </div>
                                </td>
                                <td class="px-6 py-4 text-gray-600">{{ $servicio->vehiculo->marca ?? '-' }} {{ $servicio->vehiculo->modelo ?? '' }}</td>
                                <td class="px-6 py-4 text-gray-600">{{ $servicio->vehiculo->cliente->nombre ?? '-' }}</td>
                                <td class="px-6 py-4 text-gray-600">{{ $servicio->fecha ? $servicio->fecha->format('d/m/Y') : '-' }}</td>
                                <td class="px-6 py-4">
                                    <span class="text-green-600 font-bold">${{ number_format($servicio->total, 2) }}</span>
                                </td>
                                <td class="px-6 py-4 text-center">
                                    <span class="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm font-semibold">En progreso</span>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="flex justify-center space-x-3">
                                        <a href="{{ route('servicios.show', $servicio->id) }}" 
                                           class="text-blue-600 hover:text-blue-800 transition">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="{{ route('servicios.edit', $servicio->id) }}" 
                                           class="text-green-600 hover:text-green-800 transition">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="{{ route('servicios.destroy', $servicio->id) }}" method="POST" 
                                              class="inline" onsubmit="return confirm('¿Estás seguro?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="text-red-600 hover:text-red-800 transition">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    @else
                        <tr>
                            <td colspan="7" class="px-6 py-8 text-center text-gray-500">
                                <i class="fas fa-inbox text-4xl mb-3 block opacity-50"></i>
                                <p>No hay servicios registrados. <a href="{{ route('servicios.create') }}" class="text-yellow-600 hover:underline">Crear uno ahora</a></p>
                            </td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
@endsection
