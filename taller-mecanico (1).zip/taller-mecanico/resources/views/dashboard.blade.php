@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
    <!-- Header -->
    <div class="mb-8">
        <h1 class="text-4xl font-bold text-gray-800 mb-2">Bienvenido al Sistema de Gestión</h1>
        <p class="text-gray-600">Administra tu taller mecánico de forma eficiente</p>
    </div>

    <!-- Stats Grid -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <!-- Total Clientes -->
        <div class="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition border-l-4 border-blue-600">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm font-semibold">TOTAL CLIENTES</p>
                    <p class="text-3xl font-bold text-gray-800 mt-2">{{ $stats['clientes'] ?? 0 }}</p>
                </div>
                <i class="fas fa-users text-4xl text-blue-600 opacity-20"></i>
            </div>
            <p class="text-xs text-gray-500 mt-4">
                <span class="text-green-600 font-semibold">+5</span> este mes
            </p>
        </div>

        <!-- Total Vehículos -->
        <div class="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition border-l-4 border-green-600">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm font-semibold">VEHÍCULOS</p>
                    <p class="text-3xl font-bold text-gray-800 mt-2">{{ $stats['vehiculos'] ?? 0 }}</p>
                </div>
                <i class="fas fa-car text-4xl text-green-600 opacity-20"></i>
            </div>
            <p class="text-xs text-gray-500 mt-4">
                <span class="text-green-600 font-semibold">+2</span> nuevos
            </p>
        </div>

        <!-- Servicios en Progreso -->
        <div class="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition border-l-4 border-yellow-600">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm font-semibold">EN PROGRESO</p>
                    <p class="text-3xl font-bold text-gray-800 mt-2">{{ $stats['servicios_progreso'] ?? 0 }}</p>
                </div>
                <i class="fas fa-wrench text-4xl text-yellow-600 opacity-20"></i>
            </div>
            <p class="text-xs text-gray-500 mt-4">
                Servicios activos
            </p>
        </div>

        <!-- Ingresos Totales -->
        <div class="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition border-l-4 border-red-600">
            <div class="flex items-center justify-between">
                <div>
                    <p class="text-gray-600 text-sm font-semibold">INGRESOS</p>
                    <p class="text-3xl font-bold text-gray-800 mt-2">${{ number_format($stats['ingresos'] ?? 0, 2) }}</p>
                </div>
                <i class="fas fa-dollar-sign text-4xl text-red-600 opacity-20"></i>
            </div>
            <p class="text-xs text-gray-500 mt-4">
                Este mes
            </p>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <!-- Quick Add Section -->
        <div class="lg:col-span-2 bg-white rounded-lg shadow-lg p-6">
            <h2 class="text-xl font-bold text-gray-800 mb-6">Acciones Rápidas</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <a href="{{ route('clientes.create') }}" class="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-semibold py-3 px-4 rounded-lg transition flex items-center justify-center space-x-2">
                    <i class="fas fa-user-plus"></i>
                    <span>Nuevo Cliente</span>
                </a>
                <a href="{{ route('vehiculos.create') }}" class="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-semibold py-3 px-4 rounded-lg transition flex items-center justify-center space-x-2">
                    <i class="fas fa-car-plus"></i>
                    <span>Nuevo Vehículo</span>
                </a>
                <a href="{{ route('servicios.create') }}" class="bg-gradient-to-r from-yellow-600 to-yellow-700 hover:from-yellow-700 hover:to-yellow-800 text-white font-semibold py-3 px-4 rounded-lg transition flex items-center justify-center space-x-2">
                    <i class="fas fa-wrench"></i>
                    <span>Nuevo Servicio</span>
                </a>
                <a href="{{ route('repuestos.create') }}" class="bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white font-semibold py-3 px-4 rounded-lg transition flex items-center justify-center space-x-2">
                    <i class="fas fa-box"></i>
                    <span>Nuevo Repuesto</span>
                </a>
            </div>
        </div>

        <!-- Calendar/Events -->
        <div class="bg-white rounded-lg shadow-lg p-6">
            <h2 class="text-xl font-bold text-gray-800 mb-6">Recordatorios</h2>
            <div class="space-y-3">
                <div class="p-3 bg-red-50 border-l-4 border-red-500 rounded">
                    <p class="text-sm font-semibold text-gray-800">Servicio pendiente</p>
                    <p class="text-xs text-gray-600">Audi A4 - Cambio de aceite</p>
                    <p class="text-xs text-red-600 font-semibold mt-1">Hoy</p>
                </div>
                <div class="p-3 bg-yellow-50 border-l-4 border-yellow-500 rounded">
                    <p class="text-sm font-semibold text-gray-800">Presupuesto para revisar</p>
                    <p class="text-xs text-gray-600">BMW X5 - Reparación frenos</p>
                    <p class="text-xs text-yellow-600 font-semibold mt-1">Mañana</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="bg-white rounded-lg shadow-lg p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-6">Actividad Reciente</h2>
        
        <div class="overflow-x-auto">
            <table class="w-full text-sm">
                <thead class="bg-gray-50 border-b-2 border-gray-200">
                    <tr>
                        <th class="px-6 py-3 text-left font-semibold text-gray-700">Actividad</th>
                        <th class="px-6 py-3 text-left font-semibold text-gray-700">Detalles</th>
                        <th class="px-6 py-3 text-left font-semibold text-gray-700">Fecha</th>
                        <th class="px-6 py-3 text-center font-semibold text-gray-700">Estado</th>
                    </tr>
                </thead>
                <tbody class="divide-y">
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-3">
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-user-plus text-blue-600"></i>
                                <span class="text-gray-800">Nuevo cliente registrado</span>
                            </div>
                        </td>
                        <td class="px-6 py-3 text-gray-600">Juan Pérez</td>
                        <td class="px-6 py-3 text-gray-500">Hace 2 horas</td>
                        <td class="px-6 py-3 text-center">
                            <span class="bg-green-100 text-green-800 px-3 py-1 rounded-full text-xs font-semibold">Completado</span>
                        </td>
                    </tr>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-3">
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-wrench text-yellow-600"></i>
                                <span class="text-gray-800">Servicio iniciado</span>
                            </div>
                        </td>
                        <td class="px-6 py-3 text-gray-600">Toyota Corolla - Cambio aceite</td>
                        <td class="px-6 py-3 text-gray-500">Hace 4 horas</td>
                        <td class="px-6 py-3 text-center">
                            <span class="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-xs font-semibold">En progreso</span>
                        </td>
                    </tr>
                    <tr class="hover:bg-gray-50 transition">
                        <td class="px-6 py-3">
                            <div class="flex items-center space-x-2">
                                <i class="fas fa-receipt text-purple-600"></i>
                                <span class="text-gray-800">Presupuesto generado</span>
                            </div>
                        </td>
                        <td class="px-6 py-3 text-gray-600">Honda Civic - Reparación motor</td>
                        <td class="px-6 py-3 text-gray-500">Hace 1 día</td>
                        <td class="px-6 py-3 text-center">
                            <span class="bg-orange-100 text-orange-800 px-3 py-1 rounded-full text-xs font-semibold">Pendiente</span>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
@endsection
