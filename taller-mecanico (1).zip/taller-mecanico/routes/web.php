<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\VehiculoController;
use App\Http\Controllers\ServicioController;
use App\Http\Controllers\RepuestoController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

// Rutas CRUD para Clientes
Route::resource('clientes', ClienteController::class);

// Rutas CRUD para Vehículos
Route::resource('vehiculos', VehiculoController::class);

// Rutas CRUD para Servicios
Route::resource('servicios', ServicioController::class);

// Rutas CRUD para Repuestos
Route::resource('repuestos', RepuestoController::class);
