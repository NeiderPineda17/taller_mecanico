<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(){
        Schema::create('recordatorios', function (Blueprint $table){
            $table->id();
            $table->foreignId('vehiculo_id')->constrained('vehiculos')->onDelete('cascade');
            $table->string('mensaje');
            $table->date('fecha_recordar');
            $table->boolean('enviado')->default(false);
            $table->timestamps();
        });
    }
    public function down(){
        Schema::dropIfExists('recordatorios');
    }
};
